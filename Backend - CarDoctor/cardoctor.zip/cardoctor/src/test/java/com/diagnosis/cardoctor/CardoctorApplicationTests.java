package com.diagnosis.cardoctor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CardoctorApplicationTests {

	@Test
	void contextLoads() {
	}

}
