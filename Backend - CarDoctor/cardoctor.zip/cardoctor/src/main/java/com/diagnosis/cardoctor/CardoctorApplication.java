package com.diagnosis.cardoctor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CardoctorApplication {

	public static void main(String[] args) {
		SpringApplication.run(CardoctorApplication.class, args);
	}

}
